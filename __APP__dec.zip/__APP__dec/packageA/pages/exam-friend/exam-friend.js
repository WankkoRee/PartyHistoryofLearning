// packageA/pages/exam-friend/exam-friend.js
Page({data: {}})
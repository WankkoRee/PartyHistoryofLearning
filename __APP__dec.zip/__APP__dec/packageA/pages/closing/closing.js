// packageA/pages/closing/closing.js
Page({data: {}})
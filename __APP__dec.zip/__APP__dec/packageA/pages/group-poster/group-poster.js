// packageA/pages/group-poster/group-poster.js
Page({data: {}})
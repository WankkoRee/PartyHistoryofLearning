// packageA/pages/department-ranking-list/department-ranking-list.js
Page({data: {}})
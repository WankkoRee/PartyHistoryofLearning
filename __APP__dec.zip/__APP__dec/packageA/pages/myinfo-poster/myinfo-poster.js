// packageA/pages/myinfo-poster/myinfo-poster.js
Page({data: {}})
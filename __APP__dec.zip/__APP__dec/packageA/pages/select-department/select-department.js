// packageA/pages/select-department/select-department.js
Page({data: {}})
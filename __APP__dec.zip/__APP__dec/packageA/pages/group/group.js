// packageA/pages/group/group.js
Page({data: {}})
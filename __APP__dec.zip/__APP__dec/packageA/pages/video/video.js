// packageA/pages/video/video.js
Page({data: {}})
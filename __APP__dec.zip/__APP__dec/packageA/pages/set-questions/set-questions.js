// packageA/pages/set-questions/set-questions.js
Page({data: {}})
// packageA/pages/department-index/department-index.js
Page({data: {}})
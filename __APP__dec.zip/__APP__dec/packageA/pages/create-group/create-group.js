// packageA/pages/create-group/create-group.js
Page({data: {}})
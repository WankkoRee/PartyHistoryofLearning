// packageA/pages/first-department/first-department.js
Page({data: {}})
// packageA/pages/department-member-list/department-member-list.js
Page({data: {}})
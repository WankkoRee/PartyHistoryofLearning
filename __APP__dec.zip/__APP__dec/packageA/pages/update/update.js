// packageA/pages/update/update.js
Page({data: {}})